
export interface LabData {
  // Basic (Free)
  hemoglobin?: string;
  rbc?: string;
  wbc?: string;
  platelets?: string;
  fastingSugar?: string;
  ppSugar?: string;
  hba1c?: string;

  // Pro
  creatinine?: string;
  urea?: string;
  uricAcid?: string;
  tsh?: string;
  t3?: string;
  t4?: string;
  bilirubinTotal?: string;
  sgpt?: string;
  sgot?: string;
  alkalinePhosphatase?: string;
  totalProtein?: string;
  albumin?: string;
  sodium?: string;
  potassium?: string;
  calcium?: string;
  magnesium?: string;
  chloride?: string;
  vitaminD?: string;
  vitaminB12?: string;
  iron?: string;
  ferritin?: string;
  cholesterolTotal?: string;
  hdl?: string;
  ldl?: string;
  triglycerides?: string;
  
  // Catch-all for others in manual entry or parse
  [key: string]: string | undefined;
}

export interface LabRecord {
  id: string;
  date: string;
  timestamp: number;
  data: LabData;
}

export interface FoodAnalysisResult {
  canEat: 'YES' | 'NO' | 'CAUTION';
  reasoning: string;
  nutritionalBenefits?: string;
  sideEffects?: string;
  organicAlternatives?: string;
  analysisType: 'UNIVERSAL' | 'PERSONALIZED';
}

export interface DietPlan {
  summary: string;
  safeFoods: {
    fruits: string[];
    vegetables: string[];
    proteins: string[];
    dairyAndAlts: string[];
    nutsAndSeeds: string[];
  };
  avoidFoods: string[];
  mealIdeas: string[];
}

export interface UserProfile {
  name: string;
  age: string;
  gender: string;
  medicalConditions: string[]; // e.g., Diabetes, Hypertension, CKD
  allergies: string[];
  isPro: boolean;
  labHistory: LabRecord[];
}

export enum ViewState {
  DASHBOARD = 'DASHBOARD',
  LAB_ENTRY = 'LAB_ENTRY',
  HISTORY = 'HISTORY',
  FOOD_CHECKER = 'FOOD_CHECKER',
  DIET_PLAN = 'DIET_PLAN',
  PRO_UPGRADE = 'PRO_UPGRADE',
}
