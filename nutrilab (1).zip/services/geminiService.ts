
import { GoogleGenAI, Type } from "@google/genai";
import { LabData, DietPlan, FoodAnalysisResult, UserProfile } from "../types";

// Helper to init system with key from env
const getClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("API Key not found");
  }
  return new GoogleGenAI({ apiKey });
};

const SYSTEM_INSTRUCTION = `
You are NutriLab's expert Medical Nutritionist and Clinical Pathologist System.
Your core philosophy:
1. STRICTLY advocate for organic, whole, unprocessed foods.
2. STRICTLY forbid processed, junk, packaged foods, seed oils, and refined sugars.
3. If lab data is present, interpret results with clinical precision, identifying contraindications (e.g., High Potassium = No Bananas/Potatoes).
4. If no lab data is present, provide universal safety advice based on organic principles and general health.
5. Prioritize food safety based on medical conditions.
`;

export const analyzeLabResultsFromImage = async (base64Image: string): Promise<Partial<LabData>> => {
  try {
    const client = getClient();
    const response = await client.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: 'image/png',
              data: base64Image
            }
          },
          {
            text: "Extract all laboratory test names and their values from this image. Return ONLY a JSON object where keys are standard medical abbreviations (camelCase matching our schema: hemoglobin, rbc, wbc, creatinine, tsh, etc) and values are the numbers/units found. Focus on blood, sugar, renal, liver, and thyroid panels."
          }
        ]
      },
      config: {
        responseMimeType: "application/json",
      }
    });

    if (response.text) {
      return JSON.parse(response.text);
    }
    return {};
  } catch (error) {
    console.error("Error parsing lab image:", error);
    throw error;
  }
};

export const interpretLabsAndGenerateDiet = async (
  labData: LabData,
  userProfile: UserProfile
): Promise<{ analysis: string; plan: DietPlan }> => {
  const client = getClient();
  
  const prompt = `
    Patient Profile:
    Age: ${userProfile.age}, Gender: ${userProfile.gender}
    Known Conditions: ${userProfile.medicalConditions.join(', ')}
    Allergies: ${userProfile.allergies.join(', ')}

    Lab Results:
    ${JSON.stringify(labData)}

    Task:
    1. Provide a detailed clinical interpretation of the lab results.
    2. Create a strict organic diet plan.
    3. Categorize safe foods and foods to AVOID based on specific lab values (e.g. Uric acid, Creatinine, Sugar levels).
  `;

  const response = await client.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: prompt,
    config: {
      systemInstruction: SYSTEM_INSTRUCTION,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          analysis: { type: Type.STRING },
          plan: {
            type: Type.OBJECT,
            properties: {
              summary: { type: Type.STRING },
              safeFoods: {
                type: Type.OBJECT,
                properties: {
                  fruits: { type: Type.ARRAY, items: { type: Type.STRING } },
                  vegetables: { type: Type.ARRAY, items: { type: Type.STRING } },
                  proteins: { type: Type.ARRAY, items: { type: Type.STRING } },
                  dairyAndAlts: { type: Type.ARRAY, items: { type: Type.STRING } },
                  nutsAndSeeds: { type: Type.ARRAY, items: { type: Type.STRING } }
                }
              },
              avoidFoods: { type: Type.ARRAY, items: { type: Type.STRING } },
              mealIdeas: { type: Type.ARRAY, items: { type: Type.STRING } }
            }
          }
        }
      }
    }
  });

  if (response.text) {
    return JSON.parse(response.text);
  }
  throw new Error("Failed to generate diet plan");
};

export const checkFoodSafety = async (
  foodName: string,
  labData: LabData,
  userProfile: UserProfile
): Promise<FoodAnalysisResult> => {
  const client = getClient();
  
  // Determine if we have specific data to work with
  const hasLabData = Object.keys(labData).length > 0 && Object.values(labData).some(v => v && v.length > 0);
  const hasConditions = userProfile.medicalConditions.length > 0;
  const isPersonalized = hasLabData || hasConditions;

  const contextPrompt = isPersonalized 
    ? `
      CONTEXT: PERSONALIZED CLINICAL CHECK
      Patient Conditions: ${userProfile.medicalConditions.join(', ') || 'None declared'}
      Lab Values: ${JSON.stringify(labData)}
      
      Task: Analyze "${foodName}" specifically against these medical values. 
      - If lab values (like Potassium, Uric Acid, Sugar) contraindicate this food, REJECT it.
      - If it conflicts with conditions (e.g. Sugar + Diabetes), REJECT it.
      `
    : `
      CONTEXT: UNIVERSAL ORGANIC SAFETY CHECK
      Patient has provided NO medical data.
      
      Task: Analyze "${foodName}" based on general organic health principles.
      - If it is processed, contains seed oils, refined sugar, or artificial additives, REJECT it.
      - If it is a whole, natural, organic food, APPROVE it generally.
      `;

  const prompt = `
    ${contextPrompt}
    
    General Rules:
    - Always reject ultra-processed foods.
    - Always prefer organic.
  `;

  const response = await client.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: prompt,
    config: {
      systemInstruction: SYSTEM_INSTRUCTION,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          canEat: { type: Type.STRING, enum: ["YES", "NO", "CAUTION"] },
          reasoning: { type: Type.STRING },
          nutritionalBenefits: { type: Type.STRING },
          sideEffects: { type: Type.STRING },
          organicAlternatives: { type: Type.STRING },
          analysisType: { type: Type.STRING, enum: ["UNIVERSAL", "PERSONALIZED"] }
        }
      }
    }
  });

  if (response.text) {
    return JSON.parse(response.text);
  }
  throw new Error("Failed to check food safety");
};
