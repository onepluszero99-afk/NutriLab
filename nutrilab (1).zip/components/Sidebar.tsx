
import React from 'react';
import { ViewState } from '../types';
import { Activity, FileText, Search, Utensils, Crown, History } from 'lucide-react';

interface SidebarProps {
  currentView: ViewState;
  setView: (view: ViewState) => void;
  isPro: boolean;
}

const Sidebar: React.FC<SidebarProps> = ({ currentView, setView, isPro }) => {
  const NavItem = ({ view, icon: Icon, label, highlight = false }: { view: ViewState; icon: any; label: string; highlight?: boolean }) => (
    <button
      onClick={() => setView(view)}
      className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 font-medium relative overflow-hidden group
        ${currentView === view 
          ? 'bg-white text-medical-900 shadow-lg shadow-medical-900/10' 
          : 'text-white/80 hover:bg-white/10 hover:text-white'}
        ${highlight ? 'bg-gradient-to-r from-fruit-500 to-orange-500 text-white shadow-orange-900/20 border border-orange-400/30' : ''}
      `}
    >
      <Icon size={20} className={`z-10 relative ${highlight ? 'text-white' : (currentView === view ? 'text-medical-600' : 'text-white/70 group-hover:text-white')}`} />
      <span className="z-10 relative">{label}</span>
      {currentView === view && !highlight && (
        <div className="absolute inset-0 bg-gradient-to-r from-white to-medical-50 opacity-100" />
      )}
    </button>
  );

  return (
    <div className="w-64 bg-gradient-to-b from-medical-900 to-medical-800 h-screen flex flex-col fixed left-0 top-0 z-50 text-white shadow-2xl">
      <div className="p-6 border-b border-white/10">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center shadow-lg shadow-black/10 relative overflow-hidden shrink-0">
             {/* Custom Logo: NutriLab (Flask + Leaf) */}
             <svg viewBox="0 0 100 100" className="w-10 h-10">
                <defs>
                  <linearGradient id="flaskGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#0ea5e9" />
                    <stop offset="100%" stopColor="#0284c7" />
                  </linearGradient>
                  <linearGradient id="leafGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#4ade80" />
                    <stop offset="100%" stopColor="#16a34a" />
                  </linearGradient>
                </defs>
                {/* Flask Base */}
                <path d="M35,40 L35,25 L30,25 L30,20 L70,20 L70,25 L65,25 L65,40 L80,75 C82,80 78,88 70,88 L30,88 C22,88 18,80 20,75 Z" fill="url(#flaskGrad)" />
                {/* Liquid Level */}
                <path d="M25,65 Q50,55 75,65 L78,70 C79,73 77,75 75,75 L25,75 C23,75 21,73 22,70 Z" fill="#ffffff" opacity="0.3" />
                {/* Leaf Growing out */}
                <path d="M50,20 Q40,5 25,10 Q35,25 50,20" fill="url(#leafGrad)" />
                <path d="M50,20 Q60,0 75,5 Q65,25 50,20" fill="url(#leafGrad)" />
             </svg>
          </div>
          <div>
            <h1 className="text-2xl font-extrabold tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-white to-medical-200">NutriLab</h1>
            <p className="text-[10px] uppercase tracking-widest text-medical-300 font-semibold">Med &bull; Bio &bull; Science</p>
          </div>
        </div>
      </div>

      <div className="p-4 space-y-2 flex-1 mt-4">
        <NavItem view={ViewState.DASHBOARD} icon={Activity} label="Overview" />
        <NavItem view={ViewState.LAB_ENTRY} icon={FileText} label="My Labs" />
        <NavItem view={ViewState.HISTORY} icon={History} label="History" />
        <NavItem view={ViewState.FOOD_CHECKER} icon={Search} label="Safety Checker" />
        <NavItem view={ViewState.DIET_PLAN} icon={Utensils} label="Diet Plan" />
      </div>

      <div className="p-4">
        {!isPro && (
          <div className="mb-4">
             <NavItem view={ViewState.PRO_UPGRADE} icon={Crown} label="Upgrade to Pro" highlight />
          </div>
        )}
        {isPro && (
          <div className="p-4 bg-white/10 backdrop-blur-md rounded-xl border border-white/10 mb-4">
             <div className="flex items-center gap-2 text-fruit-400 mb-1">
                <Crown size={16} className="fill-current" />
                <span className="text-sm font-bold">Pro Member</span>
             </div>
             <p className="text-xs text-medical-200">All lab tests unlocked</p>
          </div>
        )}
        
        <div className="pt-4 border-t border-white/10">
          <a 
            href="https://x.com/NutriLab01" 
            target="_blank" 
            rel="noopener noreferrer"
            className="flex items-center gap-2 text-sm text-medical-300 hover:text-white transition-colors px-2 py-2 group"
          >
            <div className="p-1 bg-black rounded-md group-hover:bg-medical-500 transition-colors">
                <svg viewBox="0 0 24 24" className="w-3 h-3 fill-white"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
            </div>
            @NutriLab01
          </a>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
