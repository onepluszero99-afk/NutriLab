
import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import { LabData, UserProfile, ViewState, DietPlan, LabRecord } from './types';
import { interpretLabsAndGenerateDiet, analyzeLabResultsFromImage, checkFoodSafety } from './services/geminiService';
import { 
  Upload, Plus, Trash2, CheckCircle, AlertTriangle, XCircle, 
  Search, Loader2, Lock, Copy, Wallet, Activity, Crown,
  Leaf, TestTube, ShieldCheck, Utensils, ArrowRight, History, Save, Calendar
} from 'lucide-react';

// --- Isolated Components (Defined OUTSIDE App to prevent re-render focus loss) ---

const LabInput = ({ id, label, placeholder, locked = false, value, onChange }: any) => (
  <div className="relative group">
    <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1.5 tracking-wider ml-1">{label}</label>
    <div className={`relative rounded-2xl transition-all duration-300 ${locked ? 'opacity-70' : 'group-focus-within:ring-4 ring-medical-100'}`}>
        <input
        type="text"
        disabled={locked}
        value={value || ''}
        onChange={(e) => onChange(id, e.target.value)}
        className={`w-full p-4 rounded-2xl border outline-none transition-all font-semibold text-sm
            ${locked 
            ? 'bg-slate-100/50 border-slate-200 text-slate-400 cursor-not-allowed' 
            : 'bg-white border-slate-200 focus:border-medical-500 text-slate-800 shadow-sm'}`}
        placeholder={placeholder}
        />
        {locked && (
        <div className="absolute top-1/2 -translate-y-1/2 right-4 text-slate-400">
            <Lock size={14} />
        </div>
        )}
    </div>
  </div>
);

const Dashboard = ({ setView, isPro }: { setView: (v: ViewState) => void, isPro: boolean }) => (
  <div className="space-y-8 animate-fade-in max-w-7xl mx-auto">
    <div className="relative rounded-[2.5rem] overflow-hidden shadow-2xl shadow-medical-500/20 transition-all hover:shadow-medical-500/30 group">
        {/* Dynamic Background */}
        <div className="absolute inset-0 bg-gradient-to-br from-medical-600 via-medical-500 to-blue-600"></div>
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-white/10 rounded-full blur-[100px] -mr-32 -mt-32 animate-pulse"></div>
        <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-organic-400/30 rounded-full blur-[80px] -ml-20 -mb-20"></div>
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10 mix-blend-overlay"></div>
        
        <div className="relative z-10 p-12 flex flex-col md:flex-row items-center justify-between gap-8">
            <div className="space-y-6 max-w-2xl">
                <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/20 backdrop-blur-md border border-white/20 text-white text-xs font-bold tracking-wider uppercase shadow-lg">
                    <div className="w-2 h-2 rounded-full bg-organic-400 animate-pulse"></div>
                    Clinical Grade System
                </div>
                <h2 className="text-5xl font-extrabold text-white leading-[1.1] tracking-tight">
                    Precision Nutrition <br/>
                    <span className="text-transparent bg-clip-text bg-gradient-to-r from-white to-medical-200">Powered by Your Biology</span>
                </h2>
                <p className="text-medical-50 text-lg font-light leading-relaxed">
                    The most advanced system for interpreting lab data into actionable, organic nutritional protocols. 
                    Analyze your bloodwork, check food safety, and optimize your health.
                </p>
                
                <div className="flex flex-wrap gap-4 pt-4">
                    <button onClick={() => setView(ViewState.LAB_ENTRY)} className="bg-white text-medical-700 hover:bg-medical-50 px-8 py-4 rounded-2xl font-bold shadow-xl transition-all hover:scale-[1.02] active:scale-95 flex items-center gap-3 group">
                        <Upload size={20} className="group-hover:-translate-y-1 transition-transform" /> 
                        Analyze Labs
                    </button>
                    {!isPro && (
                        <button 
                        onClick={() => setView(ViewState.PRO_UPGRADE)}
                        className="bg-gradient-to-r from-fruit-500 to-orange-500 hover:from-fruit-400 hover:to-orange-400 text-white px-8 py-4 rounded-2xl font-bold shadow-lg shadow-orange-500/25 transition-all hover:scale-[1.02] active:scale-95 flex items-center gap-3"
                        >
                        <Crown size={20} />
                        Unlock Pro
                        </button>
                    )}
                </div>
            </div>
            
            {/* Abstract Visual Element */}
            <div className="hidden md:block relative w-64 h-64">
                 <div className="absolute inset-0 bg-white/10 rounded-full animate-float backdrop-blur-sm border border-white/20 flex items-center justify-center">
                    <div className="absolute inset-4 bg-white/20 rounded-full animate-pulse backdrop-blur-md flex items-center justify-center border border-white/20">
                         <Activity size={64} className="text-white opacity-90" />
                    </div>
                 </div>
                 {/* Orbiting Elements */}
                 <div className="absolute top-0 left-1/2 w-12 h-12 bg-organic-400 rounded-xl -ml-6 -mt-6 blur-md opacity-60 animate-bounce"></div>
            </div>
        </div>
    </div>

    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <div onClick={() => setView(ViewState.LAB_ENTRY)} className="glass-panel p-8 rounded-[2rem] cursor-pointer group transition-all duration-300 hover:-translate-y-2 hover:shadow-glass relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-medical-500/5 rounded-full -mr-10 -mt-10 group-hover:bg-medical-500/10 transition-colors"></div>
        <div className="w-16 h-16 bg-gradient-to-br from-medical-500 to-blue-600 rounded-2xl flex items-center justify-center shadow-lg shadow-medical-500/20 mb-6 text-white group-hover:scale-110 transition-transform duration-300">
          <TestTube size={32} />
        </div>
        <h3 className="text-xl font-bold text-slate-800 mb-2 group-hover:text-medical-600 transition-colors">Lab Analysis</h3>
        <p className="text-slate-500 text-sm leading-relaxed font-medium">Upload or enter blood work. Instant clinical interpretation and abnormality detection.</p>
      </div>

      <div onClick={() => setView(ViewState.FOOD_CHECKER)} className="glass-panel p-8 rounded-[2rem] cursor-pointer group transition-all duration-300 hover:-translate-y-2 hover:shadow-glass relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-organic-500/5 rounded-full -mr-10 -mt-10 group-hover:bg-organic-500/10 transition-colors"></div>
        <div className="w-16 h-16 bg-gradient-to-br from-organic-500 to-green-600 rounded-2xl flex items-center justify-center shadow-lg shadow-organic-500/20 mb-6 text-white group-hover:scale-110 transition-transform duration-300">
          <ShieldCheck size={32} />
        </div>
        <h3 className="text-xl font-bold text-slate-800 mb-2 group-hover:text-organic-600 transition-colors">Safety Checker</h3>
        <p className="text-slate-500 text-sm leading-relaxed font-medium">Verify if specific foods are safe for your unique medical condition profile.</p>
      </div>

      <div onClick={() => setView(ViewState.HISTORY)} className="glass-panel p-8 rounded-[2rem] cursor-pointer group transition-all duration-300 hover:-translate-y-2 hover:shadow-glass relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-purple-500/5 rounded-full -mr-10 -mt-10 group-hover:bg-purple-500/10 transition-colors"></div>
        <div className="w-16 h-16 bg-gradient-to-br from-purple-400 to-purple-600 rounded-2xl flex items-center justify-center shadow-lg shadow-purple-500/20 mb-6 text-white group-hover:scale-110 transition-transform duration-300">
          <History size={32} />
        </div>
        <h3 className="text-xl font-bold text-slate-800 mb-2 group-hover:text-purple-600 transition-colors">Patient History</h3>
        <p className="text-slate-500 text-sm leading-relaxed font-medium">Track your health timeline. Compare lab results across different dates.</p>
      </div>
    </div>
  </div>
);

const LabEntry = ({ 
    labData, 
    setLabData, 
    userProfile, 
    setUserProfile, 
    isPro, 
    handleFileUpload, 
    generatePlan, 
    isLoading,
    setView,
    onSaveHistory
}: any) => {
    
    const handleLabChange = (id: string, value: string) => {
        setLabData((prev: any) => ({ ...prev, [id]: value }));
    };

    const handleProfileChange = (field: string, value: any) => {
        setUserProfile((prev: any) => ({ ...prev, [field]: value }));
    };

    return (
      <div className="space-y-8 max-w-5xl mx-auto pb-24 animate-fade-in">
        <div className="flex flex-col md:flex-row justify-between items-end gap-6 bg-white/60 backdrop-blur-md p-8 rounded-[2rem] border border-white/50 shadow-sm">
          <div>
            <h2 className="text-4xl font-extrabold text-slate-900 tracking-tight">Lab Results</h2>
            <p className="text-slate-500 mt-2 font-medium">Manually enter values or scan a report for auto-extraction.</p>
          </div>
          <div className="flex gap-4">
            <button 
                onClick={onSaveHistory}
                className="bg-white text-medical-700 border border-medical-100 shadow-lg shadow-medical-600/10 px-6 py-4 rounded-2xl flex items-center gap-2 text-sm font-bold transition-all hover:-translate-y-1 hover:shadow-xl"
            >
                <Save size={18} />
                <span>Save Record</span>
            </button>
            <div className="relative group">
                <input
                type="file"
                accept="image/*"
                onChange={handleFileUpload}
                className="hidden"
                id="file-upload"
                />
                <label 
                htmlFor="file-upload"
                className="cursor-pointer bg-gradient-to-r from-medical-700 to-medical-600 text-white shadow-lg shadow-medical-600/20 px-8 py-4 rounded-2xl flex items-center gap-3 text-sm font-bold transition-all hover:-translate-y-1 hover:shadow-xl active:translate-y-0"
                >
                {isLoading ? <Loader2 className="animate-spin" size={20}/> : <Upload size={20} />}
                <span>Scan Report (Auto)</span>
                </label>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-8">
          {/* Profile Section */}
          <div className="glass-panel p-8 rounded-[2.5rem]">
            <h3 className="font-bold text-xl mb-8 text-slate-800 flex items-center gap-3">
              <div className="p-2.5 bg-medical-100 rounded-xl text-medical-600"><Activity size={22} /></div> 
              Patient Profile
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
               <div className="md:col-span-2 space-y-2">
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider ml-1">Known Conditions</label>
                <input 
                  type="text" 
                  className="w-full p-4 border border-slate-200 rounded-2xl text-sm font-semibold focus:border-medical-500 focus:ring-4 focus:ring-medical-50 outline-none transition-all shadow-sm" 
                  placeholder="e.g. Diabetes Type 2, Hypertension"
                  value={userProfile.medicalConditions.join(', ')}
                  onChange={(e) => handleProfileChange('medicalConditions', e.target.value.split(',').map((s: string)=>s.trim()))}
                />
               </div>
               <div className="space-y-2">
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider ml-1">Age</label>
                <input 
                  type="number" 
                  className="w-full p-4 border border-slate-200 rounded-2xl text-sm font-semibold focus:border-medical-500 focus:ring-4 focus:ring-medical-50 outline-none transition-all shadow-sm" 
                  value={userProfile.age}
                  onChange={(e) => handleProfileChange('age', e.target.value)}
                />
               </div>
               <div className="space-y-2">
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider ml-1">Gender</label>
                <select 
                  className="w-full p-4 border border-slate-200 rounded-2xl text-sm font-semibold focus:border-medical-500 focus:ring-4 focus:ring-medical-50 outline-none transition-all bg-white shadow-sm"
                  value={userProfile.gender}
                  onChange={(e) => handleProfileChange('gender', e.target.value)}
                >
                  <option>Male</option>
                  <option>Female</option>
                  <option>Other</option>
                </select>
               </div>
            </div>
          </div>

          {/* Free Labs */}
          <div className="bg-white p-8 rounded-[2.5rem] shadow-lg shadow-slate-200/50 border border-slate-100 relative overflow-hidden">
             <div className="absolute top-0 left-0 w-2 h-full bg-gradient-to-b from-organic-400 to-organic-600"></div>
             <div className="flex items-center gap-3 mb-8">
               <div className="p-2.5 bg-organic-100 rounded-xl text-organic-600"><TestTube size={22} /></div>
               <h3 className="font-bold text-xl text-slate-800">Basic Blood & Sugar Profile</h3>
               <span className="ml-auto text-xs font-bold bg-organic-50 text-organic-600 px-3 py-1.5 rounded-full border border-organic-100">Free Access</span>
             </div>
             
             <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <LabInput id="hemoglobin" label="Hemoglobin" placeholder="g/dL" value={labData.hemoglobin} onChange={handleLabChange} />
                <LabInput id="rbc" label="RBC Count" placeholder="mill/mm3" value={labData.rbc} onChange={handleLabChange} />
                <LabInput id="wbc" label="Total WBC" placeholder="/cumm" value={labData.wbc} onChange={handleLabChange} />
                <LabInput id="platelets" label="Platelets" placeholder="lakh/cumm" value={labData.platelets} onChange={handleLabChange} />
                <LabInput id="fastingSugar" label="Fasting Sugar" placeholder="mg/dL" value={labData.fastingSugar} onChange={handleLabChange} />
                <LabInput id="ppSugar" label="PP Sugar" placeholder="mg/dL" value={labData.ppSugar} onChange={handleLabChange} />
                <LabInput id="hba1c" label="HbA1c" placeholder="%" value={labData.hba1c} onChange={handleLabChange} />
             </div>
          </div>

          {/* Pro Labs */}
          <div className={`bg-white p-8 rounded-[2.5rem] shadow-lg shadow-slate-200/50 border border-slate-100 relative overflow-hidden transition-all duration-500 ${!isPro ? 'opacity-95 grayscale-[0.3]' : ''}`}>
             <div className="absolute top-0 left-0 w-2 h-full bg-gradient-to-b from-fruit-400 to-fruit-600"></div>
             <div className="flex justify-between items-center mb-8">
                <div className="flex items-center gap-3">
                   <div className="p-2.5 bg-fruit-100 rounded-xl text-fruit-600"><Crown size={22} /></div>
                   <h3 className="font-bold text-xl text-slate-800">Advanced Full Body Profile</h3>
                </div>
                {!isPro && <span className="text-xs font-bold bg-slate-100 text-slate-500 border border-slate-200 px-3 py-1.5 rounded-full flex items-center gap-1.5"><Lock size={12}/> LOCKED</span>}
             </div>
             
             <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="md:col-span-3">
                    <div className="flex items-center gap-4 mb-4">
                        <h4 className="font-bold text-sm text-slate-400 uppercase tracking-wider">Renal Function Test (RFT)</h4>
                        <div className="h-[1px] flex-1 bg-slate-100"></div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <LabInput id="creatinine" label="Serum Creatinine" placeholder="mg/dL" locked={!isPro} value={labData.creatinine} onChange={handleLabChange} />
                        <LabInput id="urea" label="Blood Urea" placeholder="mg/dL" locked={!isPro} value={labData.urea} onChange={handleLabChange} />
                        <LabInput id="uricAcid" label="Uric Acid" placeholder="mg/dL" locked={!isPro} value={labData.uricAcid} onChange={handleLabChange} />
                    </div>
                </div>
                
                <div className="md:col-span-3">
                    <div className="flex items-center gap-4 mb-4 mt-2">
                        <h4 className="font-bold text-sm text-slate-400 uppercase tracking-wider">Thyroid (TFT)</h4>
                        <div className="h-[1px] flex-1 bg-slate-100"></div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <LabInput id="tsh" label="TSH" placeholder="mIU/L" locked={!isPro} value={labData.tsh} onChange={handleLabChange} />
                        <LabInput id="t3" label="T3" placeholder="ng/dL" locked={!isPro} value={labData.t3} onChange={handleLabChange} />
                        <LabInput id="t4" label="T4" placeholder="ug/dL" locked={!isPro} value={labData.t4} onChange={handleLabChange} />
                    </div>
                </div>
                
                <div className="md:col-span-3">
                     <div className="flex items-center gap-4 mb-4 mt-2">
                        <h4 className="font-bold text-sm text-slate-400 uppercase tracking-wider">Liver (LFT)</h4>
                        <div className="h-[1px] flex-1 bg-slate-100"></div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <LabInput id="sgpt" label="SGPT (ALT)" placeholder="U/L" locked={!isPro} value={labData.sgpt} onChange={handleLabChange} />
                        <LabInput id="sgot" label="SGOT (AST)" placeholder="U/L" locked={!isPro} value={labData.sgot} onChange={handleLabChange} />
                        <LabInput id="bilirubinTotal" label="Total Bilirubin" placeholder="mg/dL" locked={!isPro} value={labData.bilirubinTotal} onChange={handleLabChange} />
                    </div>
                </div>
                
                <div className="md:col-span-3">
                    <div className="flex items-center gap-4 mb-4 mt-2">
                        <h4 className="font-bold text-sm text-slate-400 uppercase tracking-wider">Vitamins & Electrolytes</h4>
                        <div className="h-[1px] flex-1 bg-slate-100"></div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <LabInput id="vitaminD" label="Vitamin D" placeholder="ng/mL" locked={!isPro} value={labData.vitaminD} onChange={handleLabChange} />
                        <LabInput id="vitaminB12" label="Vitamin B12" placeholder="pg/mL" locked={!isPro} value={labData.vitaminB12} onChange={handleLabChange} />
                        <LabInput id="sodium" label="Sodium" placeholder="mEq/L" locked={!isPro} value={labData.sodium} onChange={handleLabChange} />
                        <LabInput id="potassium" label="Potassium" placeholder="mEq/L" locked={!isPro} value={labData.potassium} onChange={handleLabChange} />
                    </div>
                </div>
             </div>
             
             {!isPro && (
               <div className="absolute inset-0 bg-white/60 backdrop-blur-[2px] flex flex-col items-center justify-center text-center p-6 z-10">
                  <div className="bg-white/90 backdrop-blur-xl p-10 rounded-[2.5rem] shadow-2xl shadow-slate-900/10 border border-white max-w-md transform transition-all hover:scale-105">
                    <div className="w-20 h-20 bg-gradient-to-br from-fruit-100 to-fruit-50 text-fruit-500 rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-lg shadow-fruit-500/20">
                      <Lock size={36} />
                    </div>
                    <h4 className="font-extrabold text-3xl text-slate-900 mb-3">Unlock Full Analysis</h4>
                    <p className="text-slate-500 mb-8 leading-relaxed font-medium">Get detailed insights for Kidney, Liver, Thyroid, Vitamins, and Electrolytes. Critical for a complete nutritional plan.</p>
                    <button onClick={() => setView(ViewState.PRO_UPGRADE)} className="w-full bg-gradient-to-r from-slate-900 to-slate-800 text-white px-8 py-4 rounded-2xl font-bold shadow-xl hover:shadow-2xl transition-all hover:-translate-y-1">Unlock Now - $4.99</button>
                  </div>
               </div>
             )}
          </div>

          <div className="flex justify-end pb-12 sticky bottom-6 z-30">
            <button 
              onClick={generatePlan}
              disabled={isLoading}
              className="bg-gradient-to-r from-organic-600 to-organic-500 hover:from-organic-500 hover:to-organic-400 text-white text-lg font-bold px-12 py-5 rounded-[2rem] shadow-2xl shadow-organic-600/30 flex items-center gap-3 transition-all hover:scale-105 active:scale-95 disabled:opacity-70 disabled:transform-none border-4 border-white/20 backdrop-blur-md"
            >
              {isLoading ? <Loader2 className="animate-spin" /> : <Utensils fill="currentColor" size={24} />}
              Generate Medical Nutrition Plan
            </button>
          </div>
        </div>
      </div>
    );
};

const HistoryView = ({ history, onLoad, onDelete }: { history: LabRecord[], onLoad: (r: LabRecord) => void, onDelete: (id: string) => void }) => {
    return (
        <div className="max-w-6xl mx-auto animate-fade-in pb-12">
            <div className="mb-10">
                <h2 className="text-4xl font-extrabold text-slate-900 tracking-tight">Patient History</h2>
                <p className="text-slate-500 mt-2 font-medium">Timeline of your clinical records. Click 'Load' to analyze past data.</p>
            </div>

            {history.length === 0 ? (
                <div className="text-center py-20 bg-white rounded-[2.5rem] border border-dashed border-slate-200">
                    <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4 text-slate-300">
                        <History size={32} />
                    </div>
                    <h3 className="text-lg font-bold text-slate-700">No records found</h3>
                    <p className="text-slate-400">Save your lab results to build a timeline.</p>
                </div>
            ) : (
                <div className="space-y-8">
                    {/* Simple Visualizer */}
                    <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-lg">
                        <h3 className="text-lg font-bold text-slate-800 mb-6 flex items-center gap-2">
                            <Activity size={20} className="text-medical-500"/> Key Metrics Trends
                        </h3>
                        <div className="overflow-x-auto">
                            <div className="flex gap-8 min-w-max px-2">
                                {history.slice().reverse().map((rec, idx) => (
                                    <div key={rec.id} className="flex flex-col items-center gap-2">
                                        <div className="text-xs font-bold text-slate-400 uppercase tracking-wider">{rec.date}</div>
                                        <div className="space-y-2 bg-slate-50 p-4 rounded-2xl border border-slate-100 w-40 text-center">
                                            <div>
                                                <div className="text-[10px] text-slate-400 font-bold">HbA1c</div>
                                                <div className="text-xl font-bold text-slate-700">{rec.data.hba1c || '-'}%</div>
                                            </div>
                                            <div className="w-full h-[1px] bg-slate-200"></div>
                                            <div>
                                                <div className="text-[10px] text-slate-400 font-bold">Sugar (F)</div>
                                                <div className="text-lg font-bold text-slate-700">{rec.data.fastingSugar || '-'}</div>
                                            </div>
                                            <div className="w-full h-[1px] bg-slate-200"></div>
                                            <div>
                                                <div className="text-[10px] text-slate-400 font-bold">Creatinine</div>
                                                <div className="text-lg font-bold text-slate-700">{rec.data.creatinine || '-'}</div>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>

                    {/* List */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {history.map((record) => (
                            <div key={record.id} className="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm hover:shadow-lg transition-all relative group">
                                <div className="flex justify-between items-start mb-4">
                                    <div className="flex items-center gap-3">
                                        <div className="p-3 bg-medical-50 rounded-xl text-medical-600">
                                            <Calendar size={20} />
                                        </div>
                                        <div>
                                            <div className="font-bold text-slate-800">{record.date}</div>
                                            <div className="text-xs text-slate-400 font-bold uppercase">ID: {record.id.slice(-4)}</div>
                                        </div>
                                    </div>
                                    <button onClick={() => onDelete(record.id)} className="p-2 hover:bg-red-50 text-slate-300 hover:text-red-500 rounded-full transition-colors">
                                        <Trash2 size={16} />
                                    </button>
                                </div>
                                <div className="flex flex-wrap gap-2 mb-6">
                                    {Object.entries(record.data).slice(0, 5).map(([k, v]) => v && (
                                        <span key={k} className="px-3 py-1 bg-slate-50 rounded-lg text-xs font-semibold text-slate-600 border border-slate-100">
                                            {k}: {v}
                                        </span>
                                    ))}
                                    {Object.keys(record.data).length > 5 && <span className="px-2 py-1 text-xs text-slate-400">...</span>}
                                </div>
                                <button 
                                    onClick={() => onLoad(record)}
                                    className="w-full py-3 rounded-xl bg-medical-50 text-medical-700 font-bold hover:bg-medical-100 transition-colors flex items-center justify-center gap-2"
                                >
                                    <Upload size={16} /> Load Data
                                </button>
                            </div>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
};

const DietResult = ({ dietPlan, labAnalysis }: { dietPlan: DietPlan | null, labAnalysis: string }) => {
    if (!dietPlan) return <div className="text-center p-20 text-slate-400 font-medium">No plan generated yet.</div>;
    return (
      <div className="max-w-7xl mx-auto space-y-8 pb-12 animate-fade-in">
        <div className="bg-slate-900 text-white p-12 rounded-[3rem] shadow-2xl shadow-slate-900/30 relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-medical-500 opacity-20 rounded-full -mr-32 -mt-32 blur-[100px] group-hover:opacity-30 transition-opacity duration-1000"></div>
          <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-organic-500 opacity-10 rounded-full -ml-20 -mb-20 blur-[80px]"></div>
          
          <div className="relative z-10 flex flex-col md:flex-row gap-12">
             <div className="flex-1">
                <div className="flex items-center gap-3 mb-6">
                    <div className="p-3 bg-white/10 rounded-2xl backdrop-blur-md border border-white/10">
                        <Activity className="text-medical-300" size={24} />
                    </div>
                    <h2 className="text-3xl font-bold">Clinical Analysis</h2>
                </div>
                <div className="prose prose-invert prose-lg max-w-none">
                    <p className="text-slate-300 leading-relaxed whitespace-pre-line font-light">{labAnalysis}</p>
                </div>
             </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Safe Foods */}
          <div className="space-y-6">
            <div className="flex items-center gap-3 mb-2 px-2">
               <div className="p-2 bg-organic-100 rounded-xl text-organic-600 shadow-sm"><CheckCircle size={20} /></div>
               <h3 className="text-2xl font-bold text-slate-800">Recommended Organic Foods</h3>
            </div>
            
            {['Fruits', 'Vegetables', 'Proteins'].map((category) => {
                let items: string[] = [];
                if(category === 'Fruits') items = dietPlan.safeFoods.fruits;
                if(category === 'Vegetables') items = dietPlan.safeFoods.vegetables;
                if(category === 'Proteins') items = [...dietPlan.safeFoods.proteins, ...dietPlan.safeFoods.nutsAndSeeds];

                return (
                    <div key={category} className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm hover:shadow-xl transition-all hover:-translate-y-1">
                        <h4 className="font-bold text-xl mb-6 text-slate-800 flex items-center gap-2">
                            <Leaf size={20} className="text-organic-500"/> {category}
                        </h4>
                        <div className="flex flex-wrap gap-3">
                            {items.map(f => (
                            <span key={f} className="px-5 py-2.5 bg-organic-50 text-organic-800 rounded-2xl text-sm font-bold border border-organic-100 shadow-sm transition-colors hover:bg-organic-100 hover:scale-105 transform cursor-default">{f}</span>
                            ))}
                        </div>
                    </div>
                )
            })}
          </div>

          {/* Avoid Foods & Meals */}
          <div className="space-y-6">
            <div className="flex items-center gap-3 mb-2 px-2">
               <div className="p-2 bg-red-100 rounded-xl text-red-600 shadow-sm"><XCircle size={20} /></div>
               <h3 className="text-2xl font-bold text-slate-800">Strict Avoid List</h3>
            </div>
            
             <div className="bg-red-50/50 backdrop-blur-sm p-8 rounded-[2.5rem] border border-red-100 shadow-inner">
               <ul className="space-y-3">
                 {dietPlan.avoidFoods.map(f => (
                   <li key={f} className="flex items-center gap-3 text-red-900 font-medium bg-white p-4 rounded-2xl shadow-sm border border-red-50">
                     <div className="p-1 bg-red-100 rounded-full shrink-0"><XCircle size={14} className="text-red-500" /></div>
                     <span>{f}</span>
                   </li>
                 ))}
               </ul>
               <div className="mt-8 bg-red-100 p-6 rounded-2xl border border-red-200 flex gap-4 items-start">
                 <AlertTriangle size={20} className="text-red-600 shrink-0 mt-1"/> 
                 <div>
                     <p className="text-sm text-red-900 font-bold uppercase tracking-wider mb-1">Medical Warning</p>
                     <p className="text-sm text-red-800 leading-relaxed">
                        Strictly avoid all processed packaged foods, refined sugars, and seed oils (Canola, Soybean, Sunflower). These are inflammatory and contraindicated.
                     </p>
                 </div>
               </div>
             </div>

             <div className="bg-gradient-to-br from-white to-medical-50/50 p-8 rounded-[2.5rem] border border-white shadow-lg shadow-slate-200/50 mt-8">
               <h4 className="font-bold text-xl mb-6 text-medical-900 flex items-center gap-3">
                   <div className="p-2 bg-medical-100 rounded-lg text-medical-600"><Utensils size={20} /></div>
                   Suggested Meal Ideas
               </h4>
               <div className="space-y-4">
                 {dietPlan.mealIdeas.map((idea, idx) => (
                   <div key={idx} className="flex gap-5 text-slate-700 bg-white/80 p-5 rounded-2xl shadow-sm border border-slate-100 items-center hover:shadow-md transition-shadow">
                     <span className="w-8 h-8 bg-medical-500 text-white rounded-xl flex items-center justify-center text-sm font-bold shrink-0 shadow-lg shadow-medical-500/30">{idx+1}</span>
                     <p className="text-sm font-semibold leading-relaxed">{idea}</p>
                   </div>
                 ))}
               </div>
             </div>
          </div>
        </div>
      </div>
    );
};

const FoodChecker = ({ foodQuery, setFoodQuery, checkFood, isLoading, foodResult, labData }: any) => {
    const hasLabData = Object.keys(labData).length > 0 && Object.values(labData).some((v: any) => v && v.length > 0);
    
    return (
    <div className="max-w-4xl mx-auto py-12 min-h-[600px] animate-fade-in">
      <div className="text-center mb-12 space-y-4">
        <div className={`inline-flex items-center gap-2 px-4 py-1.5 rounded-full border text-xs font-bold tracking-wider uppercase shadow-sm mb-4
            ${hasLabData ? 'bg-medical-50 border-medical-200 text-medical-700' : 'bg-white border-slate-200 text-slate-500'}
        `}>
            <ShieldCheck size={14} />
            {hasLabData ? "Personalized Clinical Analysis Active" : "Universal Organic Safety Mode"}
        </div>
        <h2 className="text-5xl font-extrabold text-slate-900 tracking-tight">Food Safety Checker</h2>
        <p className="text-slate-500 text-xl max-w-2xl mx-auto font-light">
            {hasLabData 
                ? "Analyzing food safety against your specific lab results and medical profile."
                : "Instantly verify if a food item meets strict organic and health standards."
            }
        </p>
      </div>
      
      <div className="relative mb-16 group max-w-2xl mx-auto">
        <div className="absolute inset-0 bg-gradient-to-r from-medical-400 to-organic-400 rounded-3xl blur-xl opacity-20 group-hover:opacity-40 transition-all duration-500 transform group-hover:scale-105"></div>
        <div className="relative bg-white rounded-3xl shadow-2xl shadow-slate-200/50 flex items-center p-3 border border-slate-100">
            <div className="pl-5 text-slate-300"><Search size={28} /></div>
            <input
            type="text"
            value={foodQuery}
            onChange={(e) => setFoodQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && checkFood()}
            placeholder="e.g. 'Raw Spinach', 'Salted Peanuts'"
            className="w-full px-6 py-5 text-xl rounded-xl focus:outline-none text-slate-700 bg-transparent placeholder:text-slate-300 font-medium"
            />
            <button 
            onClick={checkFood}
            disabled={isLoading || !foodQuery}
            className="bg-slate-900 text-white px-10 py-5 rounded-2xl font-bold hover:bg-slate-800 transition-all disabled:opacity-50 flex items-center gap-2 shadow-xl hover:shadow-2xl hover:-translate-y-1 active:translate-y-0"
            >
            {isLoading ? <Loader2 className="animate-spin" /> : "Analyze"}
            </button>
        </div>
      </div>

      {foodResult && (
        <div className="animate-fade-in-up">
            <div className={`p-1 rounded-[3rem] bg-gradient-to-br shadow-2xl ${
                foodResult.canEat === 'YES' ? 'from-organic-400 to-organic-600 shadow-organic-500/30' : 
                foodResult.canEat === 'NO' ? 'from-red-400 to-red-600 shadow-red-500/30' : 'from-amber-400 to-amber-600 shadow-amber-500/30'
            }`}>
                <div className="bg-white p-10 rounded-[2.8rem] h-full relative overflow-hidden">
                    {/* Background decoration */}
                    <div className={`absolute top-0 right-0 w-64 h-64 rounded-full blur-[80px] -mr-20 -mt-20 opacity-20 ${
                         foodResult.canEat === 'YES' ? 'bg-organic-500' : 
                         foodResult.canEat === 'NO' ? 'bg-red-500' : 'bg-amber-500'
                    }`}></div>

                    <div className="flex flex-col md:flex-row items-start md:items-center gap-8 mb-10 relative z-10">
                        <div className={`w-28 h-28 rounded-3xl flex items-center justify-center text-white text-4xl shadow-2xl shrink-0 transform rotate-3
                        ${foodResult.canEat === 'YES' ? 'bg-gradient-to-br from-organic-500 to-organic-600' : 
                            foodResult.canEat === 'NO' ? 'bg-gradient-to-br from-red-500 to-red-600' : 'bg-gradient-to-br from-amber-500 to-amber-600'}`}>
                        {foodResult.canEat === 'YES' ? <CheckCircle size={56} /> : 
                            foodResult.canEat === 'NO' ? <XCircle size={56} /> : <AlertTriangle size={56} />}
                        </div>
                        <div>
                        <div className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-2">
                            {foodResult.analysisType === 'PERSONALIZED' ? 'CLINICAL MATCH' : 'GENERAL SAFETY'}
                        </div>
                        <h3 className="text-4xl font-extrabold text-slate-900 mb-3 capitalize">{foodQuery}</h3>
                        <span className={`font-bold px-6 py-2.5 rounded-xl text-sm inline-block shadow-sm border
                            ${foodResult.canEat === 'YES' ? 'bg-organic-50 text-organic-700 border-organic-100' : 
                            foodResult.canEat === 'NO' ? 'bg-red-50 text-red-700 border-red-100' : 'bg-amber-50 text-amber-700 border-amber-100'}`}>
                            {foodResult.canEat === 'YES' ? 'APPROVED • SAFE TO EAT' : 
                            foodResult.canEat === 'NO' ? 'REJECTED • AVOID CONSUMPTION' : 'CAUTION • LIMIT INTAKE'}
                        </span>
                        </div>
                    </div>

                    <div className="space-y-6 relative z-10">
                        <div className="p-8 bg-slate-50 rounded-[2rem] border border-slate-100 shadow-inner">
                            <h4 className="font-bold text-slate-800 mb-3 flex items-center gap-2 text-lg">
                                <Activity size={18} className="text-medical-500"/> Medical Analysis
                            </h4>
                            <p className="text-slate-600 leading-relaxed text-lg">{foodResult.reasoning}</p>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            {foodResult.sideEffects && (
                                <div className="bg-red-50 p-8 rounded-[2rem] border border-red-100">
                                    <strong className="flex items-center gap-2 text-red-800 text-sm uppercase tracking-wider mb-3">
                                        <AlertTriangle size={16}/> Potential Risks
                                    </strong>
                                    <p className="text-red-900 font-medium">{foodResult.sideEffects}</p>
                                </div>
                            )}
                            
                            {foodResult.organicAlternatives && (
                                <div className="bg-organic-50 p-8 rounded-[2rem] border border-organic-100">
                                    <strong className="flex items-center gap-2 text-organic-800 text-sm uppercase tracking-wider mb-3">
                                        <Leaf size={16}/> Organic Alternative
                                    </strong>
                                    <p className="text-organic-900 font-medium">{foodResult.organicAlternatives}</p>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </div>
      )}
    </div>
)};

const ProUpgrade = ({ isPro, setIsPro, setUserProfile, setView }: any) => {
    const walletAddress = "0xf0e8ce2efa958a7f43aff327d933bba3a6803600";
    const [copied, setCopied] = useState(false);
    
    const [txHash, setTxHash] = useState("");
    const [verifying, setVerifying] = useState(false);
    const [verifyStep, setVerifyStep] = useState(0);

    const copyToClipboard = () => {
      navigator.clipboard.writeText(walletAddress);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    };

    const verifyTransaction = () => {
      if (!txHash || txHash.length < 10) {
        alert("Please enter a valid transaction hash.");
        return;
      }

      setVerifying(true);
      setVerifyStep(1);

      setTimeout(() => setVerifyStep(2), 1500); 
      setTimeout(() => setVerifyStep(3), 3500); 
      setTimeout(() => {
        setVerifyStep(4); 
        setTimeout(() => {
            setIsPro(true);
            setUserProfile((prev: any) => ({...prev, isPro: true}));
            alert("Payment Verified! NutriLab Pro Activated.");
            setView(ViewState.LAB_ENTRY);
        }, 1000);
      }, 5500);
    };

    return (
      <div className="max-w-5xl mx-auto py-10 text-center animate-fade-in">
        <div className="inline-block p-8 bg-gradient-to-br from-fruit-100 to-orange-50 rounded-full mb-8 shadow-2xl shadow-fruit-500/20 ring-8 ring-white/50 backdrop-blur-xl">
          <Crown size={72} className="text-fruit-600 fill-fruit-100" />
        </div>
        <h2 className="text-6xl font-extrabold text-slate-900 mb-6 tracking-tight">Upgrade to NutriLab Pro</h2>
        <p className="text-xl text-slate-500 mb-16 max-w-2xl mx-auto leading-relaxed font-medium">
          Unlock the full potential of your health data. Get comprehensive clinical analysis for <span className="text-medical-600 font-bold">Renal, Thyroid, Liver, Vitamins,</span> and <span className="text-medical-600 font-bold">Electrolytes.</span>
        </p>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 mb-12 text-left">
             <div className="bg-white p-10 rounded-[3rem] shadow-2xl shadow-slate-200/50 border border-slate-100 relative overflow-hidden h-full flex flex-col">
                <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-fruit-400 to-orange-500"></div>
                <h3 className="text-3xl font-bold text-slate-900 mb-8">Pro Features Include</h3>
                <ul className="space-y-5 flex-1">
                    {[
                        'Complete Renal Function Test (RFT)', 
                        'Thyroid Profile (T3, T4, TSH)', 
                        'Liver Function Test (LFT)', 
                        'Vitamin D & B12 Analysis', 
                        'Electrolytes (Na, K, Cl)', 
                        'Iron & Ferritin Profile',
                        'Priority Processing',
                        'Detailed Meal Plans'
                    ].map((feat) => (
                    <li key={feat} className="flex items-center gap-4 text-slate-700 font-bold text-lg">
                        <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center shrink-0 text-green-600 shadow-sm">
                        <CheckCircle size={16} />
                        </div>
                        {feat}
                    </li>
                    ))}
                </ul>
             </div>

             <div className="glass-card-dark p-10 rounded-[3rem] shadow-2xl border border-slate-700/50 text-white relative overflow-hidden">
                <div className="absolute top-0 right-0 w-80 h-80 bg-medical-500 opacity-20 rounded-full blur-[100px] -mr-20 -mt-20 animate-pulse"></div>
                
                <div className="relative z-10">
                    <div className="flex justify-between items-center mb-10">
                        <div>
                            <span className="block text-slate-400 text-xs uppercase font-bold tracking-widest mb-1">Lifetime Access</span>
                            <span className="text-6xl font-bold text-white tracking-tight">$4.99</span>
                        </div>
                        <div className="p-4 bg-white/10 rounded-2xl backdrop-blur-md border border-white/10 shadow-lg">
                            <Wallet size={36} className="text-fruit-400" />
                        </div>
                    </div>

                    <div className="space-y-8">
                        <div>
                            <div className="flex justify-between items-center mb-3">
                                <p className="text-xs text-slate-400 uppercase font-bold tracking-widest">Binance Wallet (BEP20/ERC20)</p>
                                <img src="https://cryptologos.cc/logos/binance-coin-bnb-logo.png" alt="BNB" className="w-6 h-6 opacity-80"/>
                            </div>
                            <div className="flex items-center gap-3 bg-black/40 p-5 rounded-2xl border border-white/10 font-mono text-sm md:text-base text-slate-200 break-all relative group">
                                {walletAddress}
                                <button onClick={copyToClipboard} className="absolute right-2 top-1/2 -translate-y-1/2 bg-white/10 hover:bg-white/20 p-2 rounded-lg transition-colors text-fruit-400 backdrop-blur-sm">
                                    {copied ? <CheckCircle size={18} /> : <Copy size={18} />}
                                </button>
                            </div>
                        </div>

                        <div className="pt-8 border-t border-white/10">
                            <label className="block text-xs text-slate-400 mb-3 uppercase font-bold tracking-widest">Transaction Verification</label>
                            
                            <div className="space-y-4">
                                <input 
                                    type="text" 
                                    placeholder="Enter Transaction Hash (0x...)" 
                                    className="w-full bg-black/40 border border-white/10 rounded-2xl p-4 text-base text-white focus:border-fruit-500 outline-none transition-colors shadow-inner"
                                    value={txHash}
                                    onChange={(e) => setTxHash(e.target.value)}
                                    disabled={verifying && verifyStep !== 5}
                                />
                                
                                {verifying ? (
                                    <div className="bg-white/5 rounded-2xl p-4 border border-white/5 space-y-3 backdrop-blur-md">
                                        <div className="flex items-center gap-3">
                                            {verifyStep < 4 ? <Loader2 className="animate-spin text-fruit-400" size={18}/> : <CheckCircle className="text-green-500" size={18}/>}
                                            <span className="text-sm font-mono text-slate-300">
                                                {verifyStep === 1 && "Connecting to Blockchain Node..."}
                                                {verifyStep === 2 && "Locating Transaction Hash..."}
                                                {verifyStep === 3 && "Verifying Recipient & Amount..."}
                                                {verifyStep === 4 && "Payment Confirmed! Unlocking..."}
                                            </span>
                                        </div>
                                        <div className="h-1.5 w-full bg-white/10 rounded-full overflow-hidden">
                                            <div 
                                                className="h-full bg-gradient-to-r from-fruit-500 to-orange-500 transition-all duration-500 ease-out shadow-[0_0_10px_rgba(234,179,8,0.5)]" 
                                                style={{width: `${verifyStep * 25}%`}}
                                            ></div>
                                        </div>
                                    </div>
                                ) : (
                                    <button 
                                        onClick={verifyTransaction}
                                        className="w-full bg-gradient-to-r from-fruit-500 to-orange-600 hover:from-fruit-400 hover:to-orange-500 text-white font-bold py-4 rounded-2xl shadow-lg shadow-orange-900/40 transition-all hover:scale-[1.02] active:scale-95 flex items-center justify-center gap-2 text-lg"
                                    >
                                        <ShieldCheck size={20}/> Verify Payment Now
                                    </button>
                                )}
                            </div>
                        </div>
                    </div>
                </div>
             </div>
        </div>
      </div>
    );
};

// --- Main App Component ---

function App() {
  // App State
  const [currentView, setView] = useState<ViewState>(ViewState.DASHBOARD);
  const [isPro, setIsPro] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  
  // Data State
  const [labData, setLabData] = useState<LabData>({});
  const [userProfile, setUserProfile] = useState<UserProfile>({
    name: 'Guest User',
    age: '',
    gender: 'Male',
    medicalConditions: [],
    allergies: [],
    isPro: false,
    labHistory: []
  });
  const [dietPlan, setDietPlan] = useState<DietPlan | null>(null);
  const [labAnalysis, setLabAnalysis] = useState<string>("");

  // Food Checker State
  const [foodQuery, setFoodQuery] = useState("");
  const [foodResult, setFoodResult] = useState<any>(null);

  // Handlers
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsLoading(true);
    try {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64String = reader.result as string;
        const base64Data = base64String.split(',')[1];
        const extractedData = await analyzeLabResultsFromImage(base64Data);
        setLabData(prev => ({ ...prev, ...extractedData }));
        setIsLoading(false);
      };
      reader.readAsDataURL(file);
    } catch (err) {
      console.error(err);
      setIsLoading(false);
    }
  };

  const generatePlan = async () => {
    if (Object.keys(labData).length === 0) {
      alert("Please enter some lab data first.");
      return;
    }
    setIsLoading(true);
    try {
      const result = await interpretLabsAndGenerateDiet(labData, userProfile);
      setLabAnalysis(result.analysis);
      setDietPlan(result.plan);
      setView(ViewState.DIET_PLAN);
    } catch (e) {
      console.error(e);
      alert("Failed to generate plan. Please check your internet or API key.");
    } finally {
      setIsLoading(false);
    }
  };

  const checkFood = async () => {
    if (!foodQuery) return;
    setIsLoading(true);
    setFoodResult(null);
    try {
      const res = await checkFoodSafety(foodQuery, labData, userProfile);
      setFoodResult(res);
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveHistory = () => {
    if (Object.values(labData).filter(Boolean).length === 0) {
        alert("Enter lab data before saving.");
        return;
    }
    const newRecord: LabRecord = {
        id: Date.now().toString(),
        date: new Date().toLocaleDateString(),
        timestamp: Date.now(),
        data: { ...labData }
    };
    setUserProfile(prev => ({
        ...prev,
        labHistory: [newRecord, ...prev.labHistory]
    }));
    alert("Record saved to history!");
    setView(ViewState.HISTORY);
  };

  const handleLoadHistory = (record: LabRecord) => {
      setLabData(record.data);
      setView(ViewState.LAB_ENTRY);
  };

  const handleDeleteHistory = (id: string) => {
      setUserProfile(prev => ({
          ...prev,
          labHistory: prev.labHistory.filter(r => r.id !== id)
      }));
  };

  return (
    <div className="min-h-screen flex font-sans bg-slate-50 selection:bg-medical-200 selection:text-medical-900">
      <Sidebar currentView={currentView} setView={setView} isPro={isPro} />
      
      <main className="flex-1 ml-64 p-8 h-screen overflow-y-auto scroll-smooth">
        <header className="flex justify-between items-center mb-10 sticky top-0 bg-slate-50/80 backdrop-blur-xl z-40 py-6 -mx-8 px-10 border-b border-slate-200/50 shadow-sm transition-all">
           <div className="flex items-center gap-3 text-sm">
             <span className="text-medical-900 font-extrabold tracking-tight text-lg">NutriLab</span> 
             <ArrowRight size={14} className="text-slate-300" />
             <span className="font-bold text-medical-600 bg-medical-50 px-4 py-1.5 rounded-full border border-medical-100 uppercase text-xs tracking-wider">{currentView.replace('_', ' ')}</span>
           </div>
           <div className="flex items-center gap-6">
              {isPro && (
                <span className="bg-gradient-to-r from-fruit-100 to-orange-100 text-fruit-800 text-xs font-bold px-4 py-2 rounded-full flex items-center gap-2 border border-fruit-200 shadow-sm animate-pulse">
                  <Crown size={14} className="fill-fruit-600" /> PRO LIFETIME ACTIVE
                </span>
              )}
              <div className="flex items-center gap-4 pl-6 border-l border-slate-200">
                  <div className="text-right hidden md:block">
                      <p className="text-sm font-bold text-slate-700 leading-tight">{userProfile.name}</p>
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">{userProfile.age ? `${userProfile.age} YRS` : 'PROFILE INCOMPLETE'}</p>
                  </div>
                  <div className="w-12 h-12 bg-gradient-to-br from-medical-500 to-blue-600 rounded-full flex items-center justify-center text-white shadow-lg shadow-medical-500/30 ring-4 ring-white">
                    <span className="font-bold text-lg">{userProfile.name.charAt(0)}</span>
                  </div>
              </div>
           </div>
        </header>

        <div className="pb-20">
            {currentView === ViewState.DASHBOARD && <Dashboard setView={setView} isPro={isPro} />}
            {currentView === ViewState.LAB_ENTRY && (
                <LabEntry 
                    labData={labData} 
                    setLabData={setLabData} 
                    userProfile={userProfile} 
                    setUserProfile={setUserProfile} 
                    isPro={isPro} 
                    handleFileUpload={handleFileUpload} 
                    generatePlan={generatePlan} 
                    isLoading={isLoading}
                    setView={setView}
                    onSaveHistory={handleSaveHistory}
                />
            )}
            {currentView === ViewState.HISTORY && (
                <HistoryView 
                    history={userProfile.labHistory}
                    onLoad={handleLoadHistory}
                    onDelete={handleDeleteHistory}
                />
            )}
            {currentView === ViewState.DIET_PLAN && <DietResult dietPlan={dietPlan} labAnalysis={labAnalysis} />}
            {currentView === ViewState.FOOD_CHECKER && (
                <FoodChecker 
                    foodQuery={foodQuery} 
                    setFoodQuery={setFoodQuery} 
                    checkFood={checkFood} 
                    isLoading={isLoading} 
                    foodResult={foodResult} 
                    labData={labData}
                />
            )}
            {currentView === ViewState.PRO_UPGRADE && (
                <ProUpgrade 
                    isPro={isPro} 
                    setIsPro={setIsPro} 
                    setUserProfile={setUserProfile} 
                    setView={setView}
                />
            )}
        </div>

        <footer className="py-10 border-t border-slate-200 text-center text-slate-400 text-xs relative">
          <div className="flex justify-center items-center gap-2 mb-4 opacity-60">
            <TestTube size={16} />
            <span className="font-bold text-lg tracking-tight text-slate-500">NutriLab</span>
          </div>
          <p className="mb-6 max-w-xl mx-auto leading-relaxed">
            Advanced Medical Nutrition Intelligence System. <br/>
            Interpreting complex clinical data to provide precision organic dietary protocols.
          </p>
          <div className="flex justify-center gap-8 font-semibold text-slate-500">
            <a href="https://x.com/NutriLab01" target="_blank" rel="noreferrer" className="hover:text-medical-600 transition-colors">Twitter Support</a>
            <a href="#" className="hover:text-medical-600 transition-colors">Privacy Protocol</a>
            <a href="#" className="hover:text-medical-600 transition-colors">Terms of Service</a>
          </div>
          <p className="mt-8 text-slate-300 font-mono">&copy; {new Date().getFullYear()} NutriLab Systems. All rights reserved.</p>
        </footer>
      </main>
      
      <style>{`
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in {
            animation: fadeIn 0.5s cubic-bezier(0.16, 1, 0.3, 1) forwards;
        }
        .animate-fade-in-up {
            animation: fadeIn 0.7s cubic-bezier(0.16, 1, 0.3, 1) forwards;
        }
      `}</style>
    </div>
  );
}

export default App;
